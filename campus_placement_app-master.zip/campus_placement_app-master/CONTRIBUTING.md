# Contributions Welcome

Thanks for your interest in contributing to Navi! Contributing to open source projects like this one can be a rewarding way to learn, teach, and build experience. Not only that, contributing is a great way to get involved with social coding. We are excited to see what amazing contributions you will make, as well as how your contributions will benefit others.

## Contributers 

- [Prakhar Gupta](https://github.com/prakharepo)
